Discord Auto Chat & Delete 

Install with :

```
npm i arraylast-discord
```

or

```
npm install
```


to run the bot just use :
```
npm index
```

or

```
npm index.js
```


